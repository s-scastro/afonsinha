// Quando clicar no botão, mostra uma mensagem
document.getElementById("botao").addEventListener("click", function() {
  alert("Notícia fictícia: Taylor Swift e Kanye West surpreendem o mundo com um casamento inesperado! 💍🎤");
});
