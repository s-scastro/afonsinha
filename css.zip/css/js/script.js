// Quando clicar no botão, mostra uma mensagem
document.getElementById("botao").addEventListener("click", function() {
    alert("Nova notícia: Beyoncé e Taylor Swift vão lançar músicas novas! 🎶");
  });
  